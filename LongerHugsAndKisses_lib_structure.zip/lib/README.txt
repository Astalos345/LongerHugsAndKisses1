Dépose ici les DLL nécessaires :
- StardewValley.dll
- StardewModdingAPI.dll
- 0Harmony.dll

Ensuite pousse ce dossier dans ton dépôt GitHub.
